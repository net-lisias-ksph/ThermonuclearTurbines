SmokeScreen
===========

A plugin for Kerbal Space Program that adds an improved version of the MODEL_MULTI_PARTICLE effect
Many thanks to Nothke for the ideas and test, and to Egg for his commits and helpful code review
